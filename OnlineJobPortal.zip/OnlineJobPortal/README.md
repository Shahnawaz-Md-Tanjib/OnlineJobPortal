# JobPortal
A job portal(Partial) Created using Servlet and JSP, MYSQL
Check the screenshots to get the overview.
